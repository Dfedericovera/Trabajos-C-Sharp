﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Entidades;
using System.Threading;

namespace _20180626_SP_Console
{
    class Program
    {       
            public static void ImprimirResultados(Grupo g)
            {
                string tabla;
                tabla = g.MostrarTabla();
                Console.WriteLine(tabla);
            }
        
        static void Main(string[] args)
        {


            Torneo t = new Torneo("Rusia 2018");
            Console.Title = "Copa Mundial Rusia 2018";
            Grupo grupoD = new Grupo(Letras.D, Torneo.MAX_EQUIPOS_GRUPO);
            Grupo grupoA = new Grupo(Letras.A, Torneo.MAX_EQUIPOS_GRUPO);
            grupoA.Leer();
            grupoD.Leer();
            t.grupos.Add(grupoA);
            t.grupos.Add(grupoD);
            t.eventoResultados += ImprimirResultados;
            
            // Agregar Thread
            Thread hilo = new Thread(t.SimularGrupos);
            hilo.Start();
            Console.ReadKey();
            Console.WriteLine("presione una tecla para continuar");
            // **************
            Console.ReadKey();
            //Console.Clear();
            Console.ReadKey();

            Torneo otro = new Torneo("Japon 2022");
            Console.Title = "Copa Mundial Japon 2022";
            otro.grupos.Add(grupoD);
            otro.Leer();
            Thread otrohilo = new Thread(otro.SimularGrupos);
            otrohilo.Start();

            Console.ReadKey();
            Console.ReadKey();
            
        }
    }
}
