﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;
using System.IO;

namespace Entidades
{
    
    public class Torneo:IEntradaSalida<bool>
    {
        public const int MAX_EQUIPOS_GRUPO = 4;

        public List<Grupo> grupos;
        private string nombre;

        public delegate void ImprimirResultados(Grupo g);
        public event ImprimirResultados eventoResultados;

        public Torneo(string nombre)
        {
            this.grupos = new List<Grupo>();
            this.nombre = nombre;
        }

        public bool Leer()
        {
            bool retValue = false;
            for(int i =(int) Letras.A;i<(int)Letras.H;i++)
            {
                foreach (Grupo aux in grupos)
                {
                    if ((int)aux.grupo != i)
                    {
                        try
                        {
                            XmlSerializer serializer = new XmlSerializer(typeof(Grupo));
                            TextReader writer = new StreamReader(string.Format("grupo - {0}.xml",Enum.Parse(typeof(Letras),i.ToString())));
                            grupos.Add((Grupo)serializer.Deserialize(writer));
                            writer.Close();

                            retValue = true;
                        }
                        catch (Exception e)
                        {
                            Console.WriteLine(e.Message);
                            retValue = false;
                        }
                    }
                }
            }
            return retValue;
        }

        public bool Guardar()
        {
            bool retValue = false;
            foreach (Grupo aux in this.grupos)
            {                
                try
                {
                    XmlSerializer serializer = new XmlSerializer(typeof(Grupo));
                    TextWriter writer = new StreamWriter(string.Format("grupo - {0}.xml",aux.grupo));
                    serializer.Serialize(writer, aux);
                    writer.Close();

                    retValue = true;
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                    retValue = false;
                }
                
            }
            return retValue;
        }

        public void SimularGrupos()
        {
            foreach (Grupo aux in grupos)
            {
                aux.Simular();
                eventoResultados(aux);
            }
            
        }
    }
}
