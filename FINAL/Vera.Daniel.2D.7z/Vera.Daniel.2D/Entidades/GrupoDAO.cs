﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Data.SqlClient;
using System.Data;

namespace Entidades
{
    public static class GrupoDAO
    {
        private static SqlConnection _conexion;
        private static SqlCommand _comando;

        static GrupoDAO()
        {
            GrupoDAO._conexion = new SqlConnection(Properties.Settings.Default.CadenaDeConexion);
            GrupoDAO._comando = new SqlCommand();
            GrupoDAO._comando.CommandType = System.Data.CommandType.Text;
            GrupoDAO._comando.Connection = GrupoDAO._conexion;
        }

        public static Grupo ObtieneGrupo(Grupo grupo)
        {
            bool TodoOk = false;

            try
            {
                // LE PASO LA INSTRUCCION SQL
                GrupoDAO._comando.CommandText = string.Format("SELECT id,nombre FROM Equipos WHERE grupo = '{0}'",grupo.grupo.ToString());

                // ABRO LA CONEXION A LA BD
                GrupoDAO._conexion.Open();

                // EJECUTO EL COMMAND                 
                SqlDataReader oDr = GrupoDAO._comando.ExecuteReader();

                // MIENTRAS TENGA REGISTROS...
                while (oDr.Read())
                {
                    grupo += new Equipo(int.Parse(oDr["id"].ToString()), oDr["nombre"].ToString());              
                }

                //CIERRO EL DATAREADER
                oDr.Close();

                TodoOk = true;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
            finally
            {
                if (TodoOk)
                    GrupoDAO._conexion.Close();
            }
            return grupo;
        }
    }
}
