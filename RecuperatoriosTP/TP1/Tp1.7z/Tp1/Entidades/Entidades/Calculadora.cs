﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    // <summary>
    // Clase Calculadora Realiza una operacion matematica entre dos objetos del tipo Numero
    // </summary>
    public class Calculadora
    {
        /// <summary>
        /// Recibe por parámetro dos objetos del tipo Numero y un string que indica 
        /// la operacion matemática a realizar.Retornando un double con el valor 
        /// obtenido tras la operación.
        /// </summary>
        /// <param name="numero1"> Primer objeto para operar </param>
        /// <param name="numero2"> Segundo objeto para operar </param>
        /// <param name="operador"> String que define el tipo de operación matemática 
        /// a realizar </param>
        /// <returns> double El resultado de la operación matemática </returns>
        public double Operar(Numero n1, Numero n2,string operador)
        {
            string operadorValido = ValidarOperador(operador);
            double retValue=0;
            switch (operadorValido)
            {
                case "+":
                    retValue = n1 + n2;                    
                    break;
                case "-":
                    retValue = n1 - n2;
                    break;
                case "*":
                    retValue = n1 * n2;
                    break;
                case "/":
                    retValue = n1 / n2;
                    break;
            }
            return retValue;
        }
        // <summary>
        //validar que el operador recibido sea +, -, / o*. Caso contrario retornará +.
        // <param> "operador" Es el string a validar.
        private string ValidarOperador(string operador)
        {
            if(operador == "+" || operador == "-" || operador == "*" || operador == "/")
            {
                return operador;
            }
            return "+";            
        }

    }
}