﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;

namespace Entidades
{
    public class Numero
    {
        private double numero;

        public Numero()
        { }

        public Numero(double numero)
        {
            this.numero = numero;
        }
        /// <summary> 
        /// Constructor parametrizado
        /// Valida el string recibido y lo carga en el atributo numero de la clase. 
        /// </summary>
        /// <param name="numero"> string a validar y cargar</param>
        public Numero(string strNumero)
        {
            this.SetNumero = strNumero;
        }

        public string SetNumero
        {
            set
            {
                this.numero = ValidarNumero(value);
            }
        }
        /// <summary>
        /// Recibe un string a validar, si es valido lo retorna como un double y en caso contrario retorna cero.
        /// </summary>
        /// <param name="strNumero"> Es el string a validar y retornar </param>
        /// <returns> El string validado como un numero double si todo OK o cero (0) en caso de error. </returns>
        private double ValidarNumero(string strNumero)
        {            
            double retValue = 0;
            if (double.TryParse(strNumero,out retValue))
            {
                return retValue;
            }
            return retValue;            
        }
        /// <summary>
        /// Recibe un string binario a convertir y lo retorna como decimal. Si no es posible retorna "Valor invalido".
        /// </summary>
        /// <param name="strNumero"> Es el string a convertir </param>
        /// <returns> El string convertido como decimal si fue posible. "Valor invalido" en caso de error. </returns>
        public string BinarioDecimal(string binario)
        {
            double numero = 0;
            int b;
            
            for (int i = binario.Length - 1; i >= 0; i--)
            {
                
                if (binario[binario.Length - i - 1] == '0' || binario[binario.Length - i - 1] == '1')
                {
                    if (int.TryParse(binario[binario.Length - i - 1].ToString(), out b))
                    {
                        numero = (b * Math.Pow(2, i))+numero;
                    }
                }
                else
                {
                    return "Valor Invalido";
                }
            }
            return numero.ToString();
        }

        /// <summary>
        /// Recibe un double a convertir y lo retorna como string binario.
        /// </summary>
        /// <param name="strNumero"> Es el string a convertir </param>
        /// <returns> El double convertido como string. </returns>
        public string DecimalBinario(double numero)
        {
            string binario = "";
            do
            {
                if ((numero % 2) == 0)
                {
                    binario = "0" + binario;
                }
                else
                {
                    binario = "1" + binario;
                }
                numero = (int)(numero / 2);
            } while (numero > 0);
            return binario;
        }

        public string DecimalBinario(string numero)
        {
            double numValido;
            string retValue;
            if(double.TryParse(numero,out numValido))
            {
                 retValue= DecimalBinario(numValido);
            }
            else
            {
                return "Valor Invalido";
            }
            return retValue;
        }

        public static double operator-(Numero n1, Numero n2)
        {
            return (n1.numero - n2.numero);
        }
        public static double operator+(Numero n1, Numero n2)
        {
            return (n1.numero + n2.numero);
        }
        public static double operator*(Numero n1, Numero n2)
        {
            return (n1.numero * n2.numero);
        }
        public static double operator /(Numero n1, Numero n2)
        {
            return (n1.numero / n2.numero);
        }
    }
}
