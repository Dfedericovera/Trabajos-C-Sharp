﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Entidades;

namespace Calculadora_de_Vera_Daniel_Federico_del_curso_2ºC
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Limpiar()
        {
            this.textBox1.Clear();
            this.textBox2.Clear();
            this.cmbOperador.ResetText();
            lvlResultado.ResetText();
        }

        static double Operar(string numero1, string numero2, string operador)
        {
            Calculadora calculadora = new Calculadora();
            Numero n1 = new Numero(numero1);
            Numero n2 = new Numero(numero2);
            return calculadora.Operar(n1, n2, operador);
        }
        private void btnOperar_Click(object sender, EventArgs e)
        {
            try
            {
                if (cmbOperador.SelectedItem != null)
                {
                    lvlResultado.Text = (Operar(textBox2.Text, textBox1.Text, cmbOperador.SelectedItem.ToString())).ToString();
                }                
                else
                {
                    lvlResultado.Text = (Operar(textBox2.Text, textBox1.Text, "+")).ToString();
                }
            }
            catch(Exception)
            {
                lvlResultado.Text = "0";
            }
        }
        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            Limpiar();
        }

        private void btnCerrar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnConvertirABinario_Click(object sender, EventArgs e)
        {
            
            Numero n1 = new Numero(lvlResultado.Text);
            lvlResultado.Text = n1.DecimalBinario(lvlResultado.Text);
        }

        private void btnConvertirADecimal_Click(object sender, EventArgs e)
        {
            Numero n1 = new Numero(lvlResultado.Text);
            lvlResultado.Text = n1.BinarioDecimal(lvlResultado.Text);
        }
    }
}
