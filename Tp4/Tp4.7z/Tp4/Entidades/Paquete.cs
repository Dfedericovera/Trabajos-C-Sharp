﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace Entidades
{
    
    public class Paquete:IMostrar<Paquete>
    {
        public enum EEstado {Ingresado, EnViaje, Entregado};
        public delegate void DelegadoEstado(Object sender, EventArgs e);
        public event DelegadoEstado InformaEstado;
        public delegate void DelegadoException(Exception e);
        public event DelegadoException InformaException;


        private string direccionEntrega;
        private EEstado estado;
        private string trakingID;

#region Propiedades

        public string DireccionEntrega
        {
            get
            {
                return this.direccionEntrega;
            }
            set
            {
                this.direccionEntrega = value;
            }
        }

        public EEstado Estado
        {
            get
            {
                return this.estado;
            }
            set
            {
                this.estado = value;
            }
        }
        public string TrakingID
        {
            get
            {
                return this.trakingID;
            }
            set
            {
                this.trakingID = value;
            }
        }
        #endregion

#region Metodos
        public Paquete(string direccionEntrega,string trakingID)
        {
            this.direccionEntrega = direccionEntrega;
            this.trakingID = trakingID;
        }
        public override string ToString()
        {
            return this.MostrarDatos(this);
        }
        public static bool operator==(Paquete p1,Paquete p2)
        {
            bool retValue = false;
            if(p1.trakingID==p2.trakingID)
            {
                retValue = true;
            }
            return retValue;
        }
        public static bool operator!=(Paquete p1, Paquete p2)
        {
            return !(p1 == p2);
        }
        public void MockCicloDeVida()
        {
            for(int i = 0;i<3;i++)
            {
                Estado = (EEstado) i;
                InformaEstado(this,new EventArgs());
                Thread.Sleep(2000);
            }
            try
            {
                PaqueteDAO.Insertar(this);
            }
            catch(Exception e)
            {
                InformaException(e);
            }
        }

        public string MostrarDatos(IMostrar<Paquete> elemento)
        {
            return string.Format("{0} Para {1}", this.TrakingID, this.DireccionEntrega);
        }
        #endregion
    }
}
