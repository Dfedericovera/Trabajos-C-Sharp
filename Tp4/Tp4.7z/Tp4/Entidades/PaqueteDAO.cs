﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Data.SqlClient;
using System.Data;

namespace Entidades
{
    public static class PaqueteDAO
    {
        private static SqlConnection _conexion;
        private static SqlCommand _comando;

        static PaqueteDAO()
        {
            PaqueteDAO._conexion = new SqlConnection(Properties.Settings.Default.CadenaDeConexion);
            PaqueteDAO._comando = new SqlCommand();
            PaqueteDAO._comando.CommandType = System.Data.CommandType.Text;
            PaqueteDAO._comando.Connection = PaqueteDAO._conexion;
        }

        public static bool Insertar(Paquete p)
        {
            string sql = "INSERT INTO correo-sp-2017 (direccionEntrega,trackingID,alumno) VALUES(";
            sql = sql + "'" + p.DireccionEntrega + "','" + p.TrakingID + "'," + "Vera,Daniel" + ")";

            bool todoOk = false;
            try
            {
                _comando.CommandText = sql;
                _conexion.Open();
                _comando.ExecuteNonQuery();
                todoOk = true;
            }
            catch (Exception e)
            {
                todoOk = false;
                throw e;                
            }
            finally
            {
                if (todoOk)
                    _conexion.Close();
            }
            return todoOk;
        }
    }
}
