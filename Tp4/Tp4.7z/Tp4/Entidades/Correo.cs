﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Threading;

namespace Entidades
{
    public class Correo:IMostrar<List<Paquete>>
    {
        List<Thread> mockPaquetes;
        List<Paquete> paquetes;
        #region Propiedades

        public List<Paquete> Paquetes
        {
            get
            {
                return this.paquetes;
            }
            set
            {
                this.paquetes = value;
            }
        }
        #endregion

        #region Metodos

        public Correo()
        {
            this.mockPaquetes = new List<Thread>();
            this.paquetes = new List<Paquete>();
        }

        public string MostrarDatos(IMostrar< List<Paquete>> elemento)
        {
            StringBuilder sb = new StringBuilder();
            foreach (Paquete p in this.Paquetes)
            {
                sb.AppendFormat("{0} para {1} ({2})\n", p.TrakingID, p.DireccionEntrega, p.Estado.ToString());
            }
            return sb.ToString();
        }

        public void FinEntregas()
        {
            foreach (Thread aux in this.mockPaquetes)
            {
                aux.Abort();                
            }
        }

        public static Correo operator +(Correo c, Paquete p)
        {
            foreach(Paquete aux in c.paquetes)
            {
                if(aux==p)
                {
                    throw new TrakingIDRepetidoException("El paquete ya se encuentra en la lista");                    
                    return c;
                }
            }
            c.paquetes.Add(p);
            Thread hilo = new Thread(p.MockCicloDeVida);
            c.mockPaquetes.Add(hilo);
            hilo.Start();
            return c;
        }
        #endregion

    }
}
