﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

using Entidades;
namespace UnitTestProject2
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void ListaCorreo()
        {
            // Verificar que la lista de correos este instanciada  
            Correo correo = new Correo();
            Assert.IsNotNull(correo.Paquetes);
        }
        [TestMethod]
        public void MismoTrakingID()
        {
            // Verificar que no se puedan cargar dos Paquetes con el mismo Tracking ID.
            Correo correo = new Correo();
            Paquete p1 = new Paquete("mitre123", "123456");
            Paquete p2 = new Paquete("mitre123", "123456");
            try
            {
                correo += p1;
                correo += p2;
            }
            catch (Exception e)
            {
                Assert.IsInstanceOfType(e, typeof(TrakingIDRepetidoException));
            }
        }
    }
}
